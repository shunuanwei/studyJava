/**
 * 
 */
package bean;

/**纯API方式入参模型：【发起组织机构对公账号随机金额打款】
 * @author chenxi
 *
 */
public class API_PayRandomAmount {

	//对公账号开户行总行名称
	private String bank;
	//对公账号开户行所在省份名称
	private String province;
	//对公账号开户行所在城市名称
	private String city;
	//对公账号开户行支行名称全称
	private String subbranch;
	//银行卡号信息
	private String cardNo;
	//联行号信息
	private String cnapsCode;
	//业务方业务上下文id，如果不填则取发起实名时的contextId
	private String contextId;
	//打款成功后异步通知地址
	private String notifyUrl;
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSubbranch() {
		return subbranch;
	}
	public void setSubbranch(String subbranch) {
		this.subbranch = subbranch;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getCnapsCode() {
		return cnapsCode;
	}
	public void setCnapsCode(String cnapsCode) {
		this.cnapsCode = cnapsCode;
	}
	public String getContextId() {
		return contextId;
	}
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}
	public String getNotifyUrl() {
		return notifyUrl;
	}
	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}
	@Override
	public String toString() {
		return "API_PayRandomAmount [bank=" + bank + ", province=" + province + ", city=" + city + ", subbranch="
				+ subbranch + ", cardNo=" + cardNo + ", cnapsCode=" + cnapsCode + ", contextId=" + contextId
				+ ", notifyUrl=" + notifyUrl + "]";
	}
	
	
}
