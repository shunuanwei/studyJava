/**
 * 
 */
package bean;

/**纯API方式入参模型：【发起授权签署实名认证】
 * @author chenxi
 *
 */
public class API_LegalSign {

	//代理人姓名
	private String agentName;
	//代理人身份证号
	private String agentIdNo;
	//法定代表人签署手机号
	private String mobileNo;
	//法人身份证号,如果信息比对api中已传入，可为空；否则需传入
	private String legalRepIdNo;
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getAgentIdNo() {
		return agentIdNo;
	}
	public void setAgentIdNo(String agentIdNo) {
		this.agentIdNo = agentIdNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getLegalRepIdNo() {
		return legalRepIdNo;
	}
	public void setLegalRepIdNo(String legalRepIdNo) {
		this.legalRepIdNo = legalRepIdNo;
	}
	@Override
	public String toString() {
		return "API_LegalSign [agentName=" + agentName + ", agentIdNo=" + agentIdNo + ", mobileNo=" + mobileNo
				+ ", legalRepIdNo=" + legalRepIdNo + "]";
	}
	
	
}
