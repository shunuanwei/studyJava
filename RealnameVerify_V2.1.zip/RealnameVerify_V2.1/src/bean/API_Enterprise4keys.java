/**
 * 
 */
package bean;

/**纯API方式入参模型：【发起企业实名认证4要素校验】
 * @author chenxi
 *
 */
public class API_Enterprise4keys {

	//组织名称
	private String name;
	//组织证件号,支持统一社会信用代码号和15位企业工商注册号
	private String orgCode;
	//法定代表人名称
	private String legalRepName;
	//法定代表人身份证号
	private String legalRepIdNo;
	//对接方业务上下文id，将在异步通知及跳转时携带返回对接方
	private String contextId;
	//实名结束后异步通知地址,具体见"异步通知"章节说明
	private String notifyUrl;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getLegalRepName() {
		return legalRepName;
	}
	public void setLegalRepName(String legalRepName) {
		this.legalRepName = legalRepName;
	}
	public String getLegalRepIdNo() {
		return legalRepIdNo;
	}
	public void setLegalRepIdNo(String legalRepIdNo) {
		this.legalRepIdNo = legalRepIdNo;
	}
	public String getContextId() {
		return contextId;
	}
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}
	public String getNotifyUrl() {
		return notifyUrl;
	}
	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}
	@Override
	public String toString() {
		return "API_Enterprise4keys [name=" + name + ", orgCode=" + orgCode + ", legalRepName=" + legalRepName
				+ ", legalRepIdNo=" + legalRepIdNo + ", contextId=" + contextId + ", notifyUrl=" + notifyUrl + "]";
	}
	
	
	
}
