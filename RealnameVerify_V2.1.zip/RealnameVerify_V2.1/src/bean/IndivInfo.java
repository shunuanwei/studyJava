/**
 * 
 */
package bean;

/**个人认证基本信息模型
 * @author chenxi
 *
 */
public class IndivInfo {
	//个人银行卡号
    private String  bankCardNo;
    //个人证件号
    private String  certNo;
    //个人证件类型
    private String  certType;
    //个人手机号
    private String  mobileNo;
    //个人姓名
    private String  name;
    //个人证件号所属地区/国籍
    private String  nationality;
	public String getBankCardNo() {
		return bankCardNo;
	}
	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getCertType() {
		return certType;
	}
	public void setCertType(String certType) {
		this.certType = certType;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	@Override
	public String toString() {
		return "IndivInfo [bankCardNo=" + bankCardNo + ", certNo=" + certNo + ", certType=" + certType + ", mobileNo="
				+ mobileNo + ", name=" + name + ", nationality=" + nationality + "]";
	}
    
    
}
