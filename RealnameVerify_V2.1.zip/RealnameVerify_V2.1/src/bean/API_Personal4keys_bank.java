/**
 * 
 */
package bean;

/**纯API方式入参模型：【发起银行卡4要素实名认证】
 * @author chenxi
 *
 */
public class API_Personal4keys_bank {
    //姓名
	private String name;
	//身份证号
	private String idNo;
	//手机号,仅限中国大陆11位手机号
	private String mobileNo;
	//银行卡号，仅限大陆银联银行卡
	private String bankCardNo;
	//对接方业务上下文id，将在异步通知及跳转时携带返回对接方
	private String contextId;
	//实名结束后异步通知地址,具体见"异步通知"章节说明
	private String notifyUrl;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getBankCardNo() {
		return bankCardNo;
	}
	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}
	public String getContextId() {
		return contextId;
	}
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}
	public String getNotifyUrl() {
		return notifyUrl;
	}
	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}
	@Override
	public String toString() {
		return "API_Personal4keys_bank [name=" + name + ", idNo=" + idNo + ", mobileNo=" + mobileNo + ", bankCardNo="
				+ bankCardNo + ", contextId=" + contextId + ", notifyUrl=" + notifyUrl + "]";
	}
	
	
}
