/**
 * 
 */
package bean;

/**业务计费参数 模型
 * @author chenxi
 *
 */
public class BillParams {
    //用于计费的项目Id
	private String appId;
	//付费方账号Gid
	private String payerAccountGid;
	//	售卖方案Id
	private String saleSchemaId;
	//计费套餐类型
	private String scope;
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getPayerAccountGid() {
		return payerAccountGid;
	}
	public void setPayerAccountGid(String payerAccountGid) {
		this.payerAccountGid = payerAccountGid;
	}
	public String getSaleSchemaId() {
		return saleSchemaId;
	}
	public void setSaleSchemaId(String saleSchemaId) {
		this.saleSchemaId = saleSchemaId;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	@Override
	public String toString() {
		return "BillParams [appId=" + appId + ", payerAccountGid=" + payerAccountGid + ", saleSchemaId=" + saleSchemaId
				+ ", scope=" + scope + "]";
	}
	
	
}
