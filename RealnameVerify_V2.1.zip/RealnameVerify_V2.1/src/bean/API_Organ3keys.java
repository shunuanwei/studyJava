/**
 * 
 */
package bean;

/**纯API方式入参模型：【发起组织机构实名认证3要素检验】
 * @author chenxi
 *
 */
public class API_Organ3keys {

	//组织名称
	private String name;
	//组织证件号,支持统一社会信用代码号和15位企业工商注册号
	private String orgCode;
	//法定代表人名称
	private String legalRepName	;
	//对接方业务上下文id，将在异步通知及跳转时携带返回对接方
	private String contextId;
	//实名结束后异步通知地址,具体见"异步通知"章节说明
	private String notifyUrl;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getLegalRepName() {
		return legalRepName;
	}
	public void setLegalRepName(String legalRepName) {
		this.legalRepName = legalRepName;
	}
	public String getContextId() {
		return contextId;
	}
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}
	public String getNotifyUrl() {
		return notifyUrl;
	}
	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}
	@Override
	public String toString() {
		return "API_Organ3keys [name=" + name + ", orgCode=" + orgCode + ", legalRepName=" + legalRepName
				+ ", contextId=" + contextId + ", notifyUrl=" + notifyUrl + "]";
	}
	
	
	
}
