/**
 * 
 */
package bean;

/**纯API方式入参模型：【申请刷脸地址进行人脸识别认证】
 * @author chenxi
 *
 */
public class API_PersonalFaceVerify {
	  //姓名
      private String  name;
      //身份证号
      private String  idNo;
      //刷脸方式，详见:个人已支持刷脸方式对照表
      private String  faceauthMode;
      //刷脸完成后业务重定向地址
      private String  callbackUrl;
      //对接方业务上下文id，将在异步通知及跳转时携带返回对接方
      private String  contextId;
      //实名结束后异步通知地址,具体见"异步通知"章节说明
      private String  notifyUrl;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	public String getFaceauthMode() {
		return faceauthMode;
	}
	public void setFaceauthMode(String faceauthMode) {
		this.faceauthMode = faceauthMode;
	}
	public String getCallbackUrl() {
		return callbackUrl;
	}
	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}
	public String getContextId() {
		return contextId;
	}
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}
	public String getNotifyUrl() {
		return notifyUrl;
	}
	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}
	@Override
	public String toString() {
		return "API_PersonalFaceVerify [name=" + name + ", idNo=" + idNo + ", faceauthMode=" + faceauthMode
				+ ", callbackUrl=" + callbackUrl + ", contextId=" + contextId + ", notifyUrl=" + notifyUrl + "]";
	}
      
      
}
