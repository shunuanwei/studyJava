package utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

import service.ConfigDemo;

/**
 * 获取Token
 * @author chenxi
 *
 */
public class TokenHelper {
	//日志记录器
	private static Logger logger  =LoggerFactory.getLogger(TokenHelper.class);
	/**
	 * 
	 * @return 返回token
	 */
	public static String getToken() {
		logger.info("-----------获取Token------------");
		String s_url  =ConfigDemo.getToken();
		String res  =HttpHelper.sendGet(s_url);
		JSONObject jparse = JSONObject.parseObject(res);
		int code  =  jparse.getInteger("code");
		if(code !=0) {
			return "error";
		}
		JSONObject data  =jparse.getJSONObject("data");
		String token = data.getString("token");
		logger.info("获得的token是:======== ");
		logger.info(token);
		logger.info("============================");
		return token ;
	}

}
