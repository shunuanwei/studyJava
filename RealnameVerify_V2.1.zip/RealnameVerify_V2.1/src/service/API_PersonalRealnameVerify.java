/**
 * 
 */
package service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

import bean.API_Personal3keys_telecom;
import bean.API_Personal4keys_bank;
import bean.API_PersonalFaceVerify;
import utils.HttpHelper;

/**认证服务纯API接入方式:个人实名认证
 * @author chenxi
 *
 */
public class API_PersonalRealnameVerify {

	        // 日志记录器
			private Logger logger = LoggerFactory.getLogger(getClass());
			private String token;

			public API_PersonalRealnameVerify() {

			}

			public API_PersonalRealnameVerify(String token) {
				this.token = token;
			}
			//------------纯API方式: 个人认证-------------------------
			/**纯API方式:【申请刷脸地址进行人脸识别认证】
			 * 
			 * @param api_PersonalFaceVerify 纯API方式入参模型：【申请刷脸地址进行人脸识别认证】
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> applyForPersonalFaceVerify(API_PersonalFaceVerify  api_PersonalFaceVerify) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				String flowId = "";
				String authUrl = "";
				String originalUrl = "";
				long expire =0l;
				String jspell = JSONObject.toJSONString(api_PersonalFaceVerify);
				String s_url = ConfigDemo.startFaceVerify();
				String res = "";
				logger.info("============纯API方式【发起运营商3要素实名认证】==========");
				res = HttpHelper.sendPost(s_url, this.token, jspell);
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					map.put("flowId", flowId);
					map.put("authUrl", authUrl);
					map.put("originalUrl", originalUrl);
					map.put("expire", String.valueOf(expire));
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				flowId = data.getString("flowId");
				authUrl = data.getString("authUrl");
				originalUrl = data.getString("originalUrl");
				expire = data.getLongValue("expire");
				map.put("flowId", flowId);
				map.put("authUrl", authUrl);
				map.put("originalUrl", originalUrl);
				map.put("expire", String.valueOf(expire));
				logger.info("实名流程Id： " + flowId);
				logger.info("e签宝短链接地址： " + authUrl);
				logger.info("刷脸原始地址： " + originalUrl);
				logger.info("链接失效时间,毫秒值： " + expire);
				logger.info("====================================");
				return map;
			}
			
			/**纯API方式:【查询个人刷脸状态】
			 * 
			 * @param flowId 发起刷脸时的id
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> queryForPersonalFaceVerifyResult(String flowId) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				String status = "";
				String message = "";
				String s_url = ConfigDemo.queryPersonalFaceVerify(flowId);
				String res = "";
				logger.info("============纯API方式【查询个人刷脸认证结果】==========");
				res = HttpHelper.sendGet2(s_url,token);
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					map.put("status", status);
					map.put("message", message);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				status = data.getString("status");
				message = data.getString("message");
				map.put("status", status);
				map.put("message", message);
				logger.info("刷脸结果状态： " + status);
				logger.info("刷脸结果描述： " + message);
				logger.info("====================================");
				return map;
			}
			/**纯API方式:【发起运营商3要素实名认证】
			 * 
			 * @param api_Personal3keys_telecom 纯API方式入参模型：【发起运营商3要素实名认证】
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> applyForPersonal3keys_telecomVerify(API_Personal3keys_telecom  api_Personal3keys_telecom) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				String flowId = "";
				String jspell = JSONObject.toJSONString(api_Personal3keys_telecom);
				String s_url = ConfigDemo.startPer3keys_telecom();
				String res = "";
				logger.info("============纯API方式【发起运营商3要素实名认证】==========");
				res = HttpHelper.sendPost(s_url, this.token, jspell);
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					map.put("flowId", flowId);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				flowId = data.getString("flowId");
				map.put("flowId", flowId);
				logger.info("实名流程Id： " + flowId);
				logger.info("====================================");
				return map;
			}
			/**纯API方式：【发起银行卡4要素实名认证】
			 * 
			 * @param api_Personal4keys_bank 纯API方式入参模型：【发起银行卡4要素实名认证】
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> applyForPersonal4keys_bankVerify(API_Personal4keys_bank  api_Personal4keys_bank) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				String flowId = "";
				String jspell = JSONObject.toJSONString(api_Personal4keys_bank);
				String s_url = ConfigDemo.startPer4keys_bank();
				String res = "";
				logger.info("============纯API方式【发起银行卡4要素实名认证】==========");
				res = HttpHelper.sendPost(s_url, this.token, jspell);
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					map.put("flowId", flowId);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				flowId = data.getString("flowId");
				map.put("flowId", flowId);
			
				logger.info("实名流程Id： " + flowId);
				logger.info("====================================");
				return map;
			}
			/**纯API方式：【回填校验运营商三要素短信验证码】
			 * 
			 * @param flowId 实名流程Id
			 * @param authcode 用户收到的6位验证码值
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> putPersonal3keys_telecomMsgCode(String flowId,String authcode) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				JSONObject jspell =new JSONObject();
				jspell.put("authcode", authcode);
				String s_url = ConfigDemo.putPinPer3keys_telecom(flowId);
				String res = "";
				logger.info("============纯API方式【回填校验运营商三要素短信验证码】==========");
				res = HttpHelper.sendPut(s_url, this.token, jspell.toString());
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				logger.info("====================================");
				return map;
			}
			/**纯API方式：【校验银行四要素短信验证码】
			 * 
			 * @param flowId 实名流程Id
			 * @param authcode 用户收到的6位验证码值
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> putPersonal4keys_bankMsgCode(String flowId,String authcode) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				JSONObject jspell =new JSONObject();
				jspell.put("authcode", authcode);
				String s_url = ConfigDemo.putPinPer4keys_bank(flowId);
				String res = "";
				logger.info("============纯API方式【回填校验银行四要素短信验证码】==========");
				res = HttpHelper.sendPut(s_url, this.token, jspell.toString());
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				logger.info("====================================");
				return map;
			}
}
