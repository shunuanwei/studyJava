package service;

public class ConfigDemo {
       public static String appId ="4438763774";
       public static String secret="172779a80fd8629ef07e7edf71839fb7";
       public static String grantType ="client_credentials";
       //模拟环境地址
       public static String host ="https://smlopenapi.esign.cn";
       //正式环境地址
//       public static String host ="https://openapi.esign.cn";
       
       //----------以下方法用来拼接各请求地址---------
       /**
        * 
        * @return 【获得Token】请求url
        */
       public static String getToken() {
    	   return host+"/v1/oauth2/access_token?appId="+appId+"&secret="+secret+"&grantType="+grantType;
       }
       /**
        * 
        * @return 【个人2要素信息比对】请求url
        */
       public static String verifyPer2keys() {
    	   return host+"/v2/identity/verify/individual/base";
       }
       /**
        * 
        * @return 【个人运营商3要素信息比对】请求url
        */
       public static String verifyPer3keys_telecom() {
    	   return  host+"/v2/identity/verify/individual/telecom3Factors";
       }
       /**
        * 
        * @return  【个人银行卡3要素信息比对】请求url
        */
       public static String verifyPer3keys_bank() {
    	   return  host+"/v2/identity/verify/individual/bank3Factors";
       }
       /**
        * 
        * @return  【个人银行卡4要素信息比对】请求url
        */
       public static String verifyPer4keys_bank() { 
    	   return  host+"/v2/identity/verify/individual/bank4Factors";
       }
       
       //------------------------------------------------------------------------------
       /**
        * 
        * @return 【企业2要素比对】请求url
        */
       public static String verifyEnterprise2keys() {
    	   return  host+"/v2/identity/verify/organization/enterprise/base";
       }
       /**
        * 
        * @return 【企业3要素比对】请求url
        */
       public static String verifyEnterprise3keys() {
    	   return  host+"/v2/identity/verify/organization/enterprise/bureau3Factors";
       }
       /**
        * 
        * @return 【企业4要素比对】请求url
        */
       public static String verifyEnterprise4keys() {
    	   return  host+"/v2/identity/verify/organization/enterprise/bureau4Factors";
       }
       /**
        * 
        * @return 【律所3要素信息比对】请求url
        */
       public static String verifyLawFirm3keys() {
    	   return  host+"/v2/identity/verify/organization/lawFirm";
       }
       /**
        * 
        * @return 【组织机构3要素信息比对】请求url
        */
       public static String verifyOrgan3keys() {
    	   return  host+"/v2/identity/verify/organization/verify";
       }
       /**
        * 
        * @return 【非工商组织3要素信息比对】请求url
        */
       public static String verifySocialOrgan3keys() {
    	   return  host+"/v2/identity/verify/organization/social";
       }
       
       //-------实名认证网页版---------
       /**
        * 
        * @return 【获取个人实名认证地址】请求url
        */
       public static String getPersonalRealnameUrl() {
    	   return  host+"/v2/identity/auth/web/indivAuthUrl";
       }
       /**
        * 
        * @return 【获取组织机构实名认证地址】请求url
        */
       public static String getOrganRealnameUrl() {
    	   return  host+"/v2/identity/auth/web/orgAuthUrl";
       }
       
       //------实名认证API版-------------
       /**申请刷脸地址进行人脸识别认证
        * 
        * @return 【发起个人刷脸实名认证】请求url
        * 
        */
       public static String startFaceVerify() {
    	   return  host+"/v2/identity/auth/api/individual/face";
       }
       /**对个人运营商三要素信息进行核验，成功后向手机号发送验证码
        * 
        * @return 【发起运营商3要素实名认证】请求url
        */
       public static String startPer3keys_telecom() {
    	   return  host+"/v2/identity/auth/api/individual/telecom3Factors";
       }
       /**对个人银行卡四要素信息进行核验，成功后向手机号发送验证码
        * 
        * @return【发起银行卡4要素实名认证】请求url
        */
       public static String startPer4keys_bank() {
    	   return  host+"/v2/identity/auth/api/individual/bankCard4Factors";
       }
       /**回填校验运营商三要素短信验证码
        * 
        * @param flowid 实名流程Id
        * @return【手机号验证码校验】请求url
        */
       public static String putPinPer3keys_telecom(String flowid) {
    	   return  host+"/v2/identity/auth/pub/individual/"+flowid+"/telecom3Factors";
       }
       /**查询个人刷脸认证结果
        * 
        * @param flowid 实名流程Id
        * @return【查询个人刷脸状态】请求url
        */
       public static String queryPersonalFaceVerify(String flowid) {
    	   return  host+"/v2/identity/auth/pub/individual/"+flowid+"/face";
       }
       /**校验银行四要素短信验证码
        * 
        * @param flowid 实名流程Id
        * @return【银行预留手机号验证码校验】请求url
        */
       public static String putPinPer4keys_bank(String flowid) {
    	   return  host+"/v2/identity/auth/pub/individual/"+flowid+"/bankCard4Factors";
       }
       /**发起企业实名认证4要素校验
        * 
        * @return 【发起企业实名认证4要素校验】 请求url
        */
       public static String startEnterprise4keys() {
    	   return  host+"/v2/identity/auth/api/organization/enterprise/fourFactors";
       }
       /**发起授权签署实名认证
        * 
        * @param flowid 实名流程Id
        * @return 【发起授权签署实名认证】请求url
        */
       public static String startLegalSignFlow(String flowid) {
    	   return  host+"/v2/identity/auth/api/organization/"+flowid+"/legalRepSign";
       }
       /**发起组织机构实名认证3要素检验
        * 
        * @return 【发起组织机构实名认证3要素检验】请求url
        */
       public static String startOrgan3keys() {
    	   return  host+"/v2/identity/auth/api/organization/threeFactors";
       }
       /**发起随机金额打款认证
        * 
        * @param flowid 实名流程Id
        * @return 【发起随机金额打款认证】 请求url
        */
       public static String startRandomPay(String flowid) {
    	   return  host+"/v2/identity/auth/pub/organization/"+flowid+"/transferRandomAmount";
       }
       /**查询打款进度
        * 
        * @param flowid 实名流程Id
        * @return 【查询打款进度】 请求url
        */
       public static String queryRandomPay(String flowid) {
    	   return  host+"/v2/identity/auth/pub/organization/"+flowid+"/transferProcess";
       }
       /**【查询打款银行信息】
        * 
        * @param flowid 实名流程Id
        * @return 【查询打款银行信息】 请求url
        */
       public static String queryBankInfoByKeywords(String flowid,String keyWord) {
    	   return  host+"/v2/identity/auth/pub/organization/"+flowid+"/subbranch?keyWord="+keyWord;
       }
       /**【查询授权书签署状态】
        * 
        * @param flowid 实名流程Id
        * @return 【查询授权书签署状态】 请求url
        */
       public static String queryLegalSignResult(String flowid) {
    	   return  host+"/v2/identity/auth/pub/organization/"+flowid+"/legalRepSignResult";
       }
       /**【获取授权签署链接】
        * 
        * @param flowid 实名流程Id
        * @return 【获取授权签署链接】 请求url
        */
       public static String queryLegalSignUrl(String flowid) {
    	   return  host+"/v2/identity/auth/pub/organization/"+flowid+"/signUrl";
       }
       /**【随机打款金额校验】
        * 
        * @param flowid 实名流程Id
        * @return 【随机打款金额校验】请求url
        */
       public static String verifyRandomAmount(String flowid) {
    	   return  host+"/v2/identity/auth/pub/organization/"+flowid+"/verifyRandomAmount";
       }
       
       //---------------公共接口------------
       /**【查询认证主流程明细】
        * 支持查询实名认证流程业务概要信息
        * @param flowid 实名流程id
        * @return 【查询认证主流程明细】请求url
        */
       public static String queryMainFlow(String flowid) {
    	   return  host+"/v2/identity/auth/api/common/"+flowid+"/outline";
       }
       /**【查询认证子流程详情】
        * 根据子业务流程查询子流程详细信息
        * @param flowid 实名流程id
        * @param subFlowId 子业务流程id
        * @return 【查询认证子流程详情】请求url
        */
       public static String queryChildFlow(String flowid,String subFlowId) {
    	   return  host+"/v2/identity/auth/api/common/"+flowid+"/process?subFlowId="+"subFlowId";
       }
       /**【查询认证信息】
        * 查询实名认证流程的流程详情，含认证状态、认证主体信息等
        * @param flowid 实名流程id
        * @return 【查询认证信息】 请求url
        */
       public static String queryVerifyInfo(String flowid) {
    	   return  host+"/v2/identity/auth/api/common/"+flowid+"/detail";
       }
}
