/**
 * 
 */
package service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

import utils.HttpHelper;

/**实名认证v2.1
 * @author chenxi
 *律所3要素、社会组织3要素、非工商组织3要素信息比对
 */
public class OtherOrganRealnameVerify {
    
    //日志记录器
	private  Logger logger  =LoggerFactory.getLogger(getClass());
	private String  token ;
	public OtherOrganRealnameVerify(){
			
		}
	public OtherOrganRealnameVerify(String  token){
			this.token = token ;
		}
	/**
	 * 律所3要素信息比对
	 * @param name 律所名称
	 * @param codeUSC 律所统一社会信用代码号
	 * @param legalRepName 律所法定代表人姓名
	 * @return 包含接口响应码、接口响应结果描述和信息比对业务Id的map集合
	 */
    public Map<String,String>  verifyLawFirm3keys(String name ,String codeUSC ,String legalRepName) {
			
			Map<String,String> map =new HashMap();
			int code =0;
			String msg ="";
			String verifyId ="";
			JSONObject jspell =new JSONObject();
			jspell.put("codeUSC",codeUSC);
			jspell.put("name", name);
			jspell.put("legalRepName", legalRepName);
			
			String s_url = ConfigDemo.verifyLawFirm3keys();
			String res ="";
			logger.info("============律所3要素信息比对==========");
			res = HttpHelper.sendPost(s_url, this.token, jspell.toString());
			JSONObject jparse = JSONObject.parseObject(res);
			code = jparse.getInteger("code");
			msg  =jparse.getString("message");
			if(code !=0) {
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				map.put("verifyId", verifyId);
				return map;
			}
			JSONObject data =  jparse.getJSONObject("data");
			verifyId =data.getString("verifyId");
			map.put("code", String.valueOf(code));
			map.put("msg", msg);
			map.put("verifyId", verifyId);
			logger.info("信息比对业务Id： "+verifyId);
			logger.info("====================================");
			return map;
		}
    /**
     * 社会组织机构3要素信息比对
     * @param name 组织名称
     * @param orgCode 组织证件号:工商企业支持15位工商注册号或统一社会信用代码;非工商组织仅支持统一社会信用代码校验
     * @param legalRepName 组织法定代表人姓名
     * @return 包含接口响应码、接口响应结果描述和信息比对业务Id的map集合
     */
     public Map<String,String>  verifyOrgan3keys(String name ,String orgCode ,String legalRepName) {
		
		Map<String,String> map =new HashMap();
		int code =0;
		String msg ="";
		String verifyId ="";
		JSONObject jspell =new JSONObject();
		jspell.put("orgCode",orgCode);
		jspell.put("name", name);
		jspell.put("legalRepName", legalRepName);
		
		String s_url = ConfigDemo.verifyOrgan3keys();
		String res ="";
		logger.info("============社会组织机构3要素信息比对==========");
		res = HttpHelper.sendPost(s_url, this.token, jspell.toString());
		JSONObject jparse = JSONObject.parseObject(res);
		code = jparse.getInteger("code");
		msg  =jparse.getString("message");
		if(code !=0) {
			map.put("code", String.valueOf(code));
			map.put("msg", msg);
			map.put("verifyId", verifyId);
			return map;
		}
		JSONObject data =  jparse.getJSONObject("data");
		verifyId =data.getString("verifyId");
		map.put("code", String.valueOf(code));
		map.put("msg", msg);
		map.put("verifyId", verifyId);
		logger.info("信息比对业务Id： "+verifyId);
		logger.info("====================================");
		return map;
	}
     /**
      * 非工商组织3要素信息比对
      * @param name 社会组织名称
      * @param codeUSC 社会组织统一社会信用代码证
      * @param legalRepName 社会组织法定代表人姓名
      * @return 包含接口响应码、接口响应结果描述和信息比对业务Id的map集合
      */
     public Map<String,String>  verifySocialOrgan3keys(String name ,String codeUSC ,String legalRepName) {
 		
 		Map<String,String> map =new HashMap();
 		int code =0;
 		String msg ="";
 		String verifyId ="";
 		JSONObject jspell =new JSONObject();
 		jspell.put("codeUSC",codeUSC);
 		jspell.put("name", name);
 		jspell.put("legalRepName", legalRepName);
 		
 		String s_url = ConfigDemo.verifySocialOrgan3keys();
 		String res ="";
 		logger.info("============非工商组织3要素信息比对==========");
 		res = HttpHelper.sendPost(s_url, this.token, jspell.toString());
 		JSONObject jparse = JSONObject.parseObject(res);
 		code = jparse.getInteger("code");
 		msg  =jparse.getString("message");
 		if(code !=0) {
 			map.put("code", String.valueOf(code));
 			map.put("msg", msg);
 			map.put("verifyId", verifyId);
 			return map;
 		}
 		JSONObject data =  jparse.getJSONObject("data");
 		verifyId =data.getString("verifyId");
 		map.put("code", String.valueOf(code));
 		map.put("msg", msg);
 		map.put("verifyId", verifyId);
 		logger.info("信息比对业务Id： "+verifyId);
 		logger.info("====================================");
 		return map;
 	}
}
