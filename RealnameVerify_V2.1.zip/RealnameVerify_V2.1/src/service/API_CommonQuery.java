/**
 * 
 */
package service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

import utils.HttpHelper;

/**认证服务纯API的【公共接口】
 * @author chenxi
 *
 */
public class API_CommonQuery {

	// 日志记录器
			private Logger logger = LoggerFactory.getLogger(getClass());
			private String token;

			public API_CommonQuery() {

			}

			public API_CommonQuery(String token) {
				this.token = token;
			}
			/**
			 * 纯API方式：【查询认证主流程明细】
			 * @param flowId 实名流程Id
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> queryMainFlow(String flowId) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				String s_url = ConfigDemo.queryMainFlow(flowId);
				String res = "";
				logger.info("============纯API方式【查询认证主流程明细】==========");
				res = HttpHelper.sendGet2(s_url,token);
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				map.put("data", data.toJSONString());
			    logger.info("返回data：>>>>>>>>>>");
			    logger.info(data.toJSONString());
				logger.info("====================================");
				return map;
			}
			/**
			 * 纯API方式：【查询认证子流程详情】
			 * @param flowId 实名流程Id
			 * @param subFlowId 子业务流程id
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> queryChildFlow(String flowId,String subFlowId)  {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				String s_url = ConfigDemo.queryChildFlow(flowId, subFlowId);
				String res = "";
				logger.info("============纯API方式【查询认证子流程详情】==========");
				res = HttpHelper.sendGet2(s_url,token);
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				map.put("data", data.toJSONString());
			    logger.info("返回data：>>>>>>>>>>");
			    logger.info(data.toJSONString());
				logger.info("====================================");
				return map;
			}
			/**
			 * 纯API方式：【查询认证信息】
			 * @param flowid 实名流程Id
			 * @return 包含接口响应码、接口响应结果描述和业务信息的map集合
			 */
			public Map<String, String> queryVerifyInfo(String flowId) {

				Map<String, String> map = new HashMap();
				int code = 0;
				String msg = "";
				String s_url = ConfigDemo.queryVerifyInfo(flowId);
				String res = "";
				logger.info("============纯API方式【查询认证信息】==========");
				res = HttpHelper.sendGet2(s_url,token);
				JSONObject jparse = JSONObject.parseObject(res);
				code = jparse.getInteger("code");
				msg = jparse.getString("message");
				if (code != 0) {
					map.put("code", String.valueOf(code));
					map.put("msg", msg);
					return map;
				}
				JSONObject data = jparse.getJSONObject("data");
				map.put("code", String.valueOf(code));
				map.put("msg", msg);
				map.put("data", data.toJSONString());
			    logger.info("返回data：>>>>>>>>>>");
			    logger.info(data.toJSONString());
				logger.info("====================================");
				return map;
			}
}
