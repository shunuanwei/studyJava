/**
 * 
 */
package service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

import bean.BillParams;
import bean.ContextInfo;
import bean.OrgEntity;
import utils.HttpHelper;

/**
 * 实名认证v2.1
 * 
 * @author chenxi 企业实名认证
 */
public class EnterpriseRealnameVerfify {
	// 日志记录器
	private Logger logger = LoggerFactory.getLogger(getClass());
	private String token;

	public EnterpriseRealnameVerfify() {

	}

	public EnterpriseRealnameVerfify(String token) {
		this.token = token;
	}

	/**
	 * 企业2要素信息比对
	 * 
	 * @param name    企业名称
	 * @param orgCode 企业证件号,支持15位工商注册号或统一社会信用代码
	 * @return 包含接口响应码、接口响应结果描述和信息比对业务Id的map集合
	 */
	public Map<String, String> verifyEnterprise2keys(String name, String orgCode) {

		Map<String, String> map = new HashMap();
		int code = 0;
		String msg = "";
		String verifyId = "";
		JSONObject jspell = new JSONObject();
		jspell.put("orgCode", orgCode);
		jspell.put("name", name);

		String s_url = ConfigDemo.verifyEnterprise2keys();
		String res = "";
		logger.info("============企业2要素信息比对==========");
		res = HttpHelper.sendPost(s_url, this.token, jspell.toString());
		JSONObject jparse = JSONObject.parseObject(res);
		code = jparse.getInteger("code");
		msg = jparse.getString("message");
		if (code != 0) {
			map.put("code", String.valueOf(code));
			map.put("msg", msg);
			map.put("verifyId", verifyId);
			return map;
		}
		JSONObject data = jparse.getJSONObject("data");
		verifyId = data.getString("verifyId");
		map.put("code", String.valueOf(code));
		map.put("msg", msg);
		map.put("verifyId", verifyId);
		logger.info("信息比对业务Id： " + verifyId);
		logger.info("====================================");
		return map;
	}

	/**
	 * 企业3要素信息比对
	 * 
	 * @param name         企业名称
	 * @param orgCode      企业证件号,支持15位工商注册号或统一社会信用代码
	 * @param legalRepName 企业法定代表人姓名
	 * @return 包含接口响应码、接口响应结果描述和信息比对业务Id的map集合
	 */
	public Map<String, String> verifyEnterprise3keys(String name, String orgCode, String legalRepName) {

		Map<String, String> map = new HashMap();
		int code = 0;
		String msg = "";
		String verifyId = "";
		JSONObject jspell = new JSONObject();
		jspell.put("orgCode", orgCode);
		jspell.put("name", name);
		jspell.put("legalRepName", legalRepName);

		String s_url = ConfigDemo.verifyEnterprise3keys();
		String res = "";
		logger.info("============企业3要素信息比对==========");
		res = HttpHelper.sendPost(s_url, this.token, jspell.toString());
		JSONObject jparse = JSONObject.parseObject(res);
		code = jparse.getInteger("code");
		msg = jparse.getString("message");
		if (code != 0) {
			map.put("code", String.valueOf(code));
			map.put("msg", msg);
			map.put("verifyId", verifyId);
			return map;
		}
		JSONObject data = jparse.getJSONObject("data");
		verifyId = data.getString("verifyId");
		map.put("code", String.valueOf(code));
		map.put("msg", msg);
		map.put("verifyId", verifyId);
		logger.info("信息比对业务Id： " + verifyId);
		logger.info("====================================");
		return map;
	}

	/**
	 * 企业4要素信息比对
	 * 
	 * @param name           企业名称
	 * @param orgCode        企业统一社会信用代码或工商注册号
	 * @param legalRepName   企业法定代表人姓名
	 * @param legalRepCertNo 企业法定代表人身份证号
	 * @return 包含接口响应码、接口响应结果描述和信息比对业务Id的map集合
	 */
	public Map<String, String> verifyEnterprise4keys(String name, String orgCode, String legalRepName,
			String legalRepCertNo) {

		Map<String, String> map = new HashMap();
		int code = 0;
		String msg = "";
		String verifyId = "";
		JSONObject jspell = new JSONObject();
		jspell.put("orgCode", orgCode);
		jspell.put("name", name);
		jspell.put("legalRepName", legalRepName);
		jspell.put("legalRepCertNo", legalRepCertNo);

		String s_url = ConfigDemo.verifyEnterprise4keys();
		String res = "";
		logger.info("============企业4要素信息比对==========");
		res = HttpHelper.sendPost(s_url, this.token, jspell.toString());
		JSONObject jparse = JSONObject.parseObject(res);
		code = jparse.getInteger("code");
		msg = jparse.getString("message");
		if (code != 0) {
			map.put("code", String.valueOf(code));
			map.put("msg", msg);
			map.put("verifyId", verifyId);
			return map;
		}
		JSONObject data = jparse.getJSONObject("data");
		verifyId = data.getString("verifyId");
		map.put("code", String.valueOf(code));
		map.put("msg", msg);
		map.put("verifyId", verifyId);
		logger.info("信息比对业务Id： " + verifyId);
		logger.info("====================================");
		return map;
	}
    /**获取组织机构实名认证地址
     * 
     * @param authType  组织机构认证类型
     * @param billParams 业务计费参数
     * @param contextInfo 业务方交互上下文信息
     * @param orgEntity 企业基本信息
     * @return
     */
	public Map<String, String> getOrganRealnameUrl(String authType, BillParams billParams, ContextInfo contextInfo,
			OrgEntity orgEntity) {
		Map<String, String> map = new HashMap();
		int code = 0;
		String msg = "";
		String flowId = "";
		String shortLink = "";
		String url = "";
		JSONObject jspell = new JSONObject();
		jspell.put("authType", authType);
		jspell.put("billParams", billParams);
		jspell.put("contextInfo", contextInfo);
		jspell.put("orgEntity", orgEntity);
		String s_url = ConfigDemo.getOrganRealnameUrl();
		String res = "";
		logger.info("============组织机构认证服务网页版：获取组织机构实名认证地址==========");
		res = HttpHelper.sendPost(s_url, this.token, jspell.toString());
		JSONObject jparse = JSONObject.parseObject(res);
		code = jparse.getInteger("code");
		msg = jparse.getString("message");
		if (code != 0) {
			map.put("code", String.valueOf(code));
			map.put("msg", msg);
			map.put("flowId", flowId);
			map.put("shortLink", shortLink);
			map.put("url", url);
			return map;
		}
		JSONObject data = jparse.getJSONObject("data");
		flowId = data.getString("flowId");
		shortLink = data.getString("shortLink");
		url = data.getString("url");
		map.put("code", String.valueOf(code));
		map.put("msg", msg);
		map.put("flowId", flowId);
		map.put("shortLink", shortLink);
		map.put("url", url);
		logger.info("认证流程Id： " + flowId);
		logger.info("实名认证地址短连接： " + shortLink);
		logger.info("实名认证地址原始链接： " + url);
		logger.info("====================================");
		return map;
	}

}
