package test;


import bean.*;
import service.EnterpriseRealnameVerfify;
import service.OtherOrganRealnameVerify;
import service.PersonRealnameVerify;
import utils.TokenHelper;
import service.API_CommonQuery;
import service.API_OrganRealnameVerify;
import service.API_PersonalRealnameVerify;


public class Test_ALL {
    public static String token ="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJnSWQiOiI4N2I4YmJhNGY2N2U0ZjRiODQ3Njc2M2FmNTRjZGYxYSIsImFwcElkIjoiNDQzODc2Mzc3NCIsIm9JZCI6ImJiZDNlYTExZWY0ZDQyNmI4NTYzNDhmYjg1MDYxM2ZmIiwidGltZXN0YW1wIjoxNTYzNzI4MzY0NjQ2fQ.6cuu_X07AyxGICfAHdNFL0UTNVaUc8H8cUypa1X7ioI";
	public static void main(String[] args) {
//		String token=TokenHelper.getToken();
		//------个人实名认证------------
//		PersonRealnameVerify pr =new PersonRealnameVerify(token);
//		pr.verifyPerson2keys("潘贺", "342922XXX01162771");
//		pr.verifyPerson3keys_telecom("潘贺", "342922XXX01162771", "18304077804");
//		pr.verifyPerson3keys_bank("潘贺", "342922XXX01162771", "6222021XXX01962462");
//		pr.verifyPerson4keys_bank("潘贺", "342922XXX01162771", "6222021XXX01962462", "18304077804");
	
		
		
		//---------企业实名认证----------
//		EnterpriseRealnameVerfify er = new EnterpriseRealnameVerfify(token);
//		er.verifyEnterprise2keys("杭州天谷信息科技有限公司", "6222021XXX01962462");
//		er.verifyEnterprise3keys("杭州天谷信息科技有限公司", "6222021XXX01962462", "何一兵");
//		er.verifyEnterprise4keys(name, orgCode, legalRepName, legalRepCertNo);
		//---------其他实名认证----------------------
//		OtherOrganRealnameVerify oor = new  OtherOrganRealnameVerify(token);
//		oor.verifyLawFirm3keys(name, codeUSC, legalRepName);
//		oor.verifyOrgan3keys(name, orgCode, legalRepName);
//		oor.verifySocialOrgan3keys(name, codeUSC, legalRepName);
		
		//-----认证服务（网页版）-------
//		BillParams bp =new  BillParams();
//		ContextInfo ci  =new  ContextInfo();
//		IndivInfo  ii =new IndivInfo();
//		OrgEntity oe =new  OrgEntity();
		
		
//		ci.setContextId("993de698a82b43d9ba6a4fb26093629e");
//		ci.setNotifyUrl("www.baidu.com");
//		ci.setOrigin("");
//		ci.setRedirectUrl("www.baidu.com");
//		ci.setShowResultPage(true);
//		//-----个人认证服务（网页版）------
//		ii.setName("潘贺");
//		ii.setCertNo("342922XXX01162771");
		
//		pr.getPersonalRealnameUrl("", bp, ci, ii);
		//-----组织机构认证服务（网页版）-------
//		oe.setName("杭州天谷信息科技有限公司");
//		oe.setCertNo("913301087458306077");
//		er.getOrganRealnameUrl("", bp, ci, oe);
		
		//-------认证服务纯API版--------
		//---个人认证服务（纯API版）---
		
//		API_PersonalRealnameVerify prvf =new API_PersonalRealnameVerify(token);
//		API_PersonalFaceVerify ap = new API_PersonalFaceVerify();
//		ap.setName("潘贺");
//		ap.setIdNo("342922XXX01162771");
//		ap.setFaceauthMode("ZHIMACREDIT");
//		ap.setCallbackUrl("www.panhecool.com");
////		[发起个人刷脸实名认证]
//		prvf.applyForPersonalFaceVerify(ap);
		//[查询个人刷脸状态]
//		prvf.queryForPersonalFaceVerifyResult("821737185324566146");
		//[发起运营商3要素实名认证]
//		API_Personal3keys_telecom akt =new API_Personal3keys_telecom();
//		akt.setName("潘贺");
//		akt.setIdNo("342922XXX01162771");
//		akt.setMobileNo("18304077804");
//		prvf.applyForPersonal3keys_telecomVerify(akt);
		//[发起银行卡4要素实名认证]
//		API_Personal4keys_bank akb  =new API_Personal4keys_bank();
//		akb.setBankCardNo("6222021316001962462");
//		akb.setName("潘贺");
//		akb.setIdNo("342922XXX01162771");
//		akb.setMobileNo("18304077804");	
//		prvf.applyForPersonal4keys_bankVerify(akb);
		//[回填校验运营商三要素短信验证码]
//		prvf.putPersonal3keys_telecomMsgCode("821780141238650559", "741234");
		//[回填校验银行四要素短信验证码]
//		prvf.putPersonal4keys_bankMsgCode("821782979675162270", "257545");
		
		//---企业/组织认证服务（纯API版）---
		API_OrganRealnameVerify orvf =new API_OrganRealnameVerify(token);
//		API_Enterprise4keys aek = new API_Enterprise4keys();
//		aek.setName("杭州天谷信息科技有限公司");
//		aek.setOrgCode("913301087458306077");
//		aek.setNotifyUrl("www.baidu.com");
//		aek.setLegalRepName("何一兵");
//		aek.setLegalRepIdNo("342922XXX01162771");
//		【发起企业实名认证4要素校验】
//		orvf.applyForEnterprise4keys(aek);
//		【发起授权签署实名认证】
//		API_LegalSign al  =new API_LegalSign();
//		al.setAgentIdNo("342922XXX01162771");
//		al.setAgentName("潘贺");
//		al.setLegalRepIdNo("342922XXX01162771");
//		al.setMobileNo("18304077804");
//		//这个需要flowid
//		orvf.startLegalSignFlow(al, "821969562097419934");
//		【发起组织机构实名认证3要素检验】
//		API_Organ3keys ao = new API_Organ3keys();
//		ao.setLegalRepName("何一兵");
//		ao.setName("杭州天谷信息科技有限公司");
//		ao.setNotifyUrl("www.baidu.com");
//		ao.setOrgCode("913301087458306077");
//		orvf.applyForOrgan3keys(ao);
		
		
		
		//----------公共接口--------
		API_CommonQuery acq = new API_CommonQuery(token);
		String flowId ="821969562097419934";
		String subFlowId ="";
//		【查询认证主流程明细】
		acq.queryMainFlow(flowId);
//		【查询认证子流程详情】
		acq.queryChildFlow(flowId, subFlowId);
//		【查询认证信息】
		acq.queryVerifyInfo(flowId);
	}
}
